Smart Mario est un jeu r�alis� pour le cours d'Algorithmique.
-------------------------------------------------------------
Pour lancer le jeu, ouvrir index.html

* Fl�che droite et Fl�che bas (ou D/S) pour d�placer mario
* Possibilit� de changer la taille de la grille et le nombre de champignons
* Essayez d'attraper le plus de champignons possibles dans le temps imparti !

--------------------
D�veloppeurs :
- Thomas BARRAS
- Guillaume SINGLAND